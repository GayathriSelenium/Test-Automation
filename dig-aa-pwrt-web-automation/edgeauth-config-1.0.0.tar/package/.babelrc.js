module.exports = function(api) {
    api.cache.never()
    return {
        env: {
            test: {
                presets: [
                    [
                        '@babel/preset-env',
                        {
                            targets: { node: '8.10' },
                        },
                    ],
                ],
            },
        },
    }
}
