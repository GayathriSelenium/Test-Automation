global.log = global.console.log
jest.spyOn(global.console, 'log').mockImplementation(() => jest.fn())
