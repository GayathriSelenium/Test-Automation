import AWSMock from 'aws-sdk-mock'
import AWS from 'aws-sdk'
import sinon from 'sinon'
import axios from 'axios'
import fs from 'fs'
import path from 'path'

let configCache = null
export const dataConfigFile = () => {
    if (configCache === null) {
        configCache = fs
            .readFileSync(
                path.resolve(__dirname, '../assets/serverlessauth.yaml'),
            )
            .toString()
    }
    return configCache
}
export const dataJwks = () => ({
    keys: [
        {
            alg: 'RS256',
            e: 'AQAB',
            kid: 'oI40SqXUY155FmYgO8a/aUjyAdmwudG7eiLXWb16c9o=',
            kty: 'RSA',
            n:
                'hH51Ii8f5kehTEQTI2exoIGr_LE2K9PoSXR61yTjpBU1hxNL4bxJQoruxQlPhQU3J_0W31Mpgl-u2dFz1a9VqeABx-gVTQBqzEDrGpBwweMQmPrfF-0npkHEUKHTpqJuDmO5Z_Dbak_slELuML_FizL5xFPUs2QUgh8Tpwqqh0EewYtLm0PPBSlEKmYdZ00-RLgdG46NwSLuqOpJ-QkrfLiINpK_3z2zmrLLr8xWZ8xYGShV9IDssYiescdsUV_xEQoS7EDVKwE_8dzJtrihhIaTbjoqruwiAKU2L25_gkHNrIKKu-dTa5IHP86jlFAvJwEv9UxViTitO2wjtORXrQ',
            use: 'sig',
        },
        {
            alg: 'RS256',
            e: 'AQAB',
            kid: 'xWGinei+Qlqgy5J1mg1NFxHhlKrnXqy6eMqIPmyqjp8=',
            kty: 'RSA',
            n:
                '7pn6Ma_dGXaOpVAZxnCA_q1VKsNOil-U51vyMt2kO4MiZC8FhmnBEb7qbYr8I1xn4ZlpXs8fqm_JA9dXrNk0mH4NngTJCodQ0hHpIf3fLeEOVSFy1vGeSV5MBlc3_AY1Ofy3d7ZHjJMEBZ2UYJ2EuczTmd5YCtOcI4O9_mm5ldSecv6tyF8JfPoD6id9jnxZyGrQUOgl9EEIRjPUX4yhymZf_5sTMAe0T-drXRjJBmYC0a41DkyIkpAz7nU7zX3nSx_jS7pp0sdXSpOGnk2uFDpRDGlGYl7IOo_x2zs8iVQoKa2RPU5iS45VZAHvNnCy7X6DW83sXAokv6311H23hw',
            use: 'sig',
        },
    ],
})

export const mockConfig = (config = dataConfigFile) => {
    AWSMock.setSDKInstance(AWS)
    //const stub = sinon.stub().resolves({ Body: Buffer.from(config()) })
    const stub = sinon.spy((params, callback) => {
        callback(null, { Body: Buffer.from(config()) })
    })
    AWSMock.mock('S3', 'getObject', stub)
    return stub
}

export const restoreConfig = () => {
    AWSMock.setSDKInstance(AWS)
    AWSMock.restore('S3')
}

export const mockJwks = () => {
    return sinon
        .stub(axios, 'get')
        .withArgs(sinon.match('.well-known/jwks.json'))
        .resolves({
            headers: {
                'cache-control': 'public, max-age=86400',
            },
            data: dataJwks(),
        })
}

export const restore = () => {
    restoreConfig()
    global._edgeauth_config = {}
    global._edgeauth_config.config = {}
    sinon.restore()
}
