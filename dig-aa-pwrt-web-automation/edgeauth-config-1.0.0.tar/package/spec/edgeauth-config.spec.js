import sinon from 'sinon'
import axios from 'axios'
import yaml from 'yaml'

import bootstrap, {
    __testS3Noop, //
    compileConfig, //
    loadJWKS, //
    parsePems, //
} from 'edgeauth-config'

import {
    dataConfigFile, //
    dataJwks, //
    mockConfig, //
    mockJwks, //
    restore, //
} from './mock'

describe('test config file', () => {
    it('returns a string', () => {
        const config = dataConfigFile()
        expect(config).toBeString()
    })
    it('returns a valid yaml', () => {
        const config = dataConfigFile()
        expect(() => yaml.parse(config)).not.toThrow()
    })
    it('returns the expected format', () => {
        const config = yaml.parse(dataConfigFile())
        expect(config.applications).toBeArray()
        expect(config.cognito).toBeObject()
        expect(config.default).toBeObject()
    })
})

describe('config dependent', () => {
    beforeEach(() => {
        mockConfig()
    })
    afterEach(() => {
        restore()
    })
    describe('compileConfig', () => {
        it('returns a single config', async () => {
            let result = await compileConfig('exampleone.com')
            expect(result).toBeObject()
        })
        it('caches s3 response', async () => {
            let result = await compileConfig('exampleone.com')
            let result2 = await compileConfig('exampleone.com')
            expect(result).toBeObject()
            expect(result2).toBeObject()

            // test that it doesnt go back to s3 @TODO
            // having issues spying on the s3 mock
        })
        it('returns a single config with cognito shortform', async () => {
            let result = await compileConfig('exampletwo.com')
            expect(result).toBeObject()
            expect(result.cognito.id).toBe('ap-southeast-2_hjyuB2tyf')
        })
        it('throws when the config is not found', async () => {
            await expect(compileConfig('doesntexist.com')).rejects.toThrow()
        })
        it('returns the last config', async () => {
            let result = await compileConfig('exampleone.com')
            const configData = yaml.parse(dataConfigFile())
            expect(result.cognito.id).toEqual(
                configData.applications.shift().cognito.id,
            )
        })
        it('injects jwt placeholders', async () => {
            let result = await compileConfig('exampleone.com')
            expect(result.jwt).toBeObject()
            expect(result.jwt.iss).toBeString()
        })
        it('injects jwks placeholders', async () => {
            let result = await compileConfig('exampleone.com')
            expect(result.jwks).toBeObject()
            expect(result.jwks.url).toBeString()
        })
        it('handles no cognito.name', async () => {
            const configYaml = dataConfigFile()
            let configParsed = yaml.parse(configYaml)
            delete configParsed.applications[0].cognito.name
            const configNew = yaml.stringify(configParsed)
            restore()
            mockConfig(() => configNew)
            let result = await compileConfig('exampleone.com')
            expect(result.cognito.id).toBe(
                configParsed.applications[0].cognito.id,
            )
        })
        it('throws when cognito config is broken', async () => {
            const configYaml = dataConfigFile()
            let configParsed = yaml.parse(configYaml)
            delete configParsed.applications[0].cognito.name
            delete configParsed.applications[0].cognito.id
            const configNew = yaml.stringify(configParsed)
            restore()
            mockConfig(() => configNew)
            expect(compileConfig('exampleone.com')).rejects.toThrow()
        })
    })
    describe('loadJWKS', () => {
        beforeEach(() => {
            mockJwks()
        })
        afterEach(() => {
            restore()
        })
        it('loads the jwks data when not set', async () => {
            let config = await compileConfig('exampleone.com')
            let result = await loadJWKS(config)
            expect(result.jwks.data).toEqual(dataJwks())
            sinon.assert.calledOnce(axios.get)
        })
        it('does not load the data when set', async () => {
            let expiry = new Date()
            expiry.setDate(expiry.getDate() + 7) // 7 days so it def wont match

            let config = await compileConfig('exampleone.com')

            config.jwks.expiry = expiry
            config.jwks.data = dataJwks()
            await loadJWKS(config)

            expect(config.jwks.expiry).toEqual(expiry)
            sinon.assert.notCalled(axios.get)
        })
        it('loads the data when expired', async () => {
            let expiry = new Date()
            expiry.setDate(expiry.getDate() - 1) // yesterday

            let config = await compileConfig('exampleone.com')

            config.jwks.expiry = expiry
            config.jwks.data = dataJwks()
            let result = await loadJWKS(config)

            expect(result.jwks.expiry).not.toEqual(expiry)
            sinon.assert.calledOnce(axios.get)
        })
        it('handles a bad expiry header gracefully', async () => {
            restore()
            mockConfig()
            sinon.stub(axios, 'get').resolves({
                headers: {
                    'cache-control': 'public, bad, max-age=abcd',
                },
                data: dataJwks(),
            })

            let config = await compileConfig('exampleone.com')

            config.jwks.data = dataJwks()
            let result = await loadJWKS(config)

            expect(result.jwks.data).toEqual(dataJwks())
            sinon.assert.calledOnce(axios.get)
        })
        it('fails when the jwks data cannot be loaded', async () => {
            restore()
            mockConfig()
            sinon.stub(axios, 'get').throws()

            let config = await compileConfig('exampleone.com')

            config.jwks.data = dataJwks()
            await expect(loadJWKS(config)).rejects.toThrow()
        })
    })
})

describe('bootstrap', () => {
    beforeEach(() => {
        mockJwks()
        mockConfig()
    })
    afterEach(() => {
        restore()
    })
    it('should provide a complete config object', async () => {
        const result = await bootstrap('exampleone.com')
        expect(result.jwks.data).toEqual(dataJwks())
        expect(result.pems).toBeObject()
    })
    describe('Caching', () => {
        it('should cache the config object', async () => {
            const clock = sinon.useFakeTimers({ shouldAdvanceTime: false })
            const now = new Date()
            let result = await bootstrap('exampleone.com')
            expect(result.createdAt).toEqual(now)
            //expect(spy.calledOnce).toBeTruthy()
            clock.restore()
        })
        it('should keep cache within 10 minutes', async () => {
            const clock = sinon.useFakeTimers({ shouldAdvanceTime: false })
            const now = new Date()
            let result = await bootstrap('exampleone.com')
            clock.tick(10 * 1000 * 60) // 10 Minutes, cache is 15
            result = await bootstrap('exampleone.com')
            expect(result.createdAt).toEqual(now)
            //expect(spy.calledOnce).toBeTruthy()
            clock.restore()
        })
        it('should invalidate the cache after 15 minutes', async () => {
            const clock = sinon.useFakeTimers({ shouldAdvanceTime: false })
            const now = new Date()
            let result = await bootstrap('exampleone.com')
            clock.tick(20 * 1000 * 60) // 20 Minutes, cache is 15, should invalidate
            result = await bootstrap('exampleone.com')
            expect(result.createdAt).not.toEqual(now)
            //expect(spy.calledTwice).toBeTruthy()
            clock.restore()
        })
    })
})

describe('parsePems', () => {
    it('parses the jwks file into a pems format', () => {
        const configData = yaml.parse(dataConfigFile())
        let config = configData.applications.shift()
        let result = parsePems({ ...config, ...{ jwks: { data: dataJwks() } } })
        expect(result.pems).toBeObject()
    })
})
