const path = require('path')

const CleanWebpackPlugin = require('clean-webpack-plugin')
const ExternalsPlugin = require('webpack-node-externals')

module.exports = () => {
    mode = 'development'

    return [
        {
            target: 'node',
            devtool: mode === 'development' ? 'source-map' : undefined,
            entry: path.resolve(__dirname, 'src/edgeauth-config.js'),
            plugins: [new CleanWebpackPlugin()],
            profile: true,
            externals: [
                ExternalsPlugin(),
                ExternalsPlugin({
                    modulesDir: path.resolve(__dirname, '../../node_modules'), //fix for yarn workspaces https://github.com/liady/webpack-node-externals/issues/39#issuecomment-356647854
                }),
            ],
            output: {
                filename: 'edgeauth-config.js',
                path: path.resolve(__dirname, 'dist'),
                library: '@origin/edgeauth-config',
                libraryTarget: 'umd',
                umdNamedDefine: true,
            },
            resolve: {
                modules: [
                    path.resolve(__dirname, 'src'),
                    path.resolve(__dirname, 'node_modules'),
                    'node_modules',
                ],
                extensions: ['.js'],
            },
            module: {
                rules: [
                    {
                        test: /\.m?[jt]s.?$/,
                        exclude: /(node_modules|bower_components)/,
                        use: {
                            loader: 'babel-loader',
                            options: {
                                presets: [
                                    [
                                        '@babel/preset-env',
                                        { targets: { node: '10' } },
                                    ],
                                ],
                            },
                        },
                    },
                ],
            },
            mode: mode,
        },
    ]
}
