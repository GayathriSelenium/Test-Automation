import axios from 'axios'
import jwkToPem from 'jwk-to-pem'
import parseCacheControl from 'parse-cache-control'
import AWS from 'aws-sdk'
import yaml from 'yaml'
import { noMutate as objectAssignDeep } from 'object-assign-deep'

import npmdebug from 'debug'

const log = npmdebug('edgeauth-config')

export const requestConfig = async () => {
    try {
        const s3 = new AWS.S3()
        const response = await s3
            .getObject({
                Bucket: 'igshared-resources',
                Key: 'Lambda/config/serverlessauth.yaml',
            })
            .promise()

        log('ConfigData was retrieved from S3')
        return yaml.parse(response.Body.toString('utf-8'))
    } catch (e) {
        throw Error('Could not load config file' + e.message)
    }
}

export const compileConfig = async (domain) => {
    try {
        const data = await requestConfig()
        const appConfig = data.applications.reduce(
            (acc, el) => (el.domains.includes(domain) ? el : acc),
            null,
        )
        if (appConfig === null) {
            throw Error('No config for domain found')
        }

        let cognitoConfig = {}
        if (
            appConfig.cognito.name &&
            Object.keys(data.cognito).includes(appConfig.cognito.name)
        ) {
            cognitoConfig = {
                cognito: data.cognito[appConfig.cognito.name],
            }
        }

        delete appConfig.cognito.name

        const compileOne = objectAssignDeep(
            {},
            data.default, // Start with defaults
            cognitoConfig, // Insert any existing cognito config
            appConfig, // Add the app config which may override the priors
        )
        const result = objectAssignDeep({}, compileOne, {
            // Generated values
            jwt: {
                iss: `https://cognito-idp.${
                    compileOne.cognito.region
                }.amazonaws.com/${compileOne.cognito.id}`,
            },
            jwks: {
                url: `https://cognito-idp.${
                    compileOne.cognito.region
                }.amazonaws.com/${compileOne.cognito.id}/.well-known/jwks.json`,
                expiry: null,
                data: null,
            },
        })

        if (!result.cognito.id || !result.cognito.domain) {
            throw Error('Cognito is misconfigured for this domain: ' + domain)
        }

        return result
    } catch (e) {
        throw Error('Could not load config from s3: ' + e.message)
    }
}

let jwksSet = {}
export const loadJWKS = async (config) => {
    let now = new Date()

    let result = {
        jwks: {},
    }

    if (
        config.jwks.data === null ||
        config.jwks.expiry === null ||
        config.jwks.expiry <= now
    ) {
        log('jwks not set or expired')
        try {
            // This is an execution level cache, ie in this execution only hit this url once.
            let jwks = jwksSet[config.jwks.url] // byreference shorthand
            jwks = jwks !== undefined ? jwks : await axios.get(config.jwks.url)
            result.jwks.data = jwks.data
            try {
                let cacheControl = parseCacheControl(
                    jwks.headers['cache-control'],
                )
                result.jwks.expiry = new Date(
                    now.getTime() + 1000 * cacheControl['max-age'],
                )
            } catch (e) {
                // survivable
                log('JWKS expiry set failed: ' + e.message)
            }
        } catch (e) {
            // not survivable
            log('JWKS fetch failed: ' + e.message)
            throw Error('Could not load JWKS')
        }
    }

    return result
}

export const parsePems = (config) => {
    let result = {
        pems: {},
    }
    let keys = config.jwks.data.keys
    for (let i = 0; i < keys.length; i++) {
        //Convert each key to PEM
        let key_id = keys[i].kid
        let modulus = keys[i].n
        let exponent = keys[i].e
        let key_type = keys[i].kty
        let jwk = { kty: key_type, n: modulus, e: exponent }
        let pem = jwkToPem(jwk)
        result.pems[key_id] = pem
    }

    log('pems loaded:', result.pems)

    return result
}

// Reference the global _edgeauth_config.config object
// This is so lambda will cache it while functions are hot.
// Also makes testing a bit more of a pain in the ass.
if (global._edgeauth_config == undefined) {
    global._edgeauth_config = {
        config: {},
    }
}

export default async (domain) => {
    const now = new Date()
    const compare = new Date(now.getTime())
    compare.setMinutes(compare.getMinutes() - 15)

    let config = global._edgeauth_config.config[domain]
    config = config == undefined ? {} : config // initialise

    if (!config.createdAt || config.createdAt <= compare) {
        log('rebuilding config for ' + domain)
        config = Object.assign(config, await compileConfig(domain))
        config = Object.assign(config, await loadJWKS(config))
        config = Object.assign(config, parsePems(config))
        config.createdAt = now
    }

    global._edgeauth_config.config[domain] = config

    log(
        '_edgeauth_config.config',
        JSON.stringify(global._edgeauth_config.config),
    )

    return config
}
