import fs from 'fs'
import { promisify } from 'util'

import AWS from 'aws-sdk'
import yaml from 'yaml'
import axios from 'axios'
import jwkToPem from 'jwk-to-pem'
import { noMutate as objectAssignDeep } from 'object-assign-deep'
import npmdebug from 'debug'
const log = npmdebug('edgeauth-config')

/*
export const requestS3 = async () => {
    const s3 = new AWS.S3()
    const response = await s3
        .getObject({
            Bucket: 'igshared-resources',
            Key: 'Lambda/config/serverlessauth.yaml',
        })
        .promise()
    return response.Body.toString('utf-8')
}
*/

export const requestLocal = async () => {
    const readFile = promisify(fs.readFile)
    return await readFile('assets/serverlessauth.yaml', 'utf8')
}

export const parse = (body) => yaml.parse(body)

export const compileCognito = (raw) => {
    const cognitoList = {}
    raw.applications.map((app) => {
        if (app.test === true) return
        const base = raw.default.cognito
        const local = app.cognito
        const name = local.name || base.name || undefined
        const preconfig = raw.cognito[name] || {}

        const { id, domain, region } = objectAssignDeep(base, preconfig, local)

        cognitoList[id] = {
            id: id,
            name: name,
            domain: domain,
            region: region,
            jwt: {
                iss: `https://cognito-idp.${region}.amazonaws.com/${id}`,
            },
            jwks: `https://cognito-idp.${region}.amazonaws.com/${id}/.well-known/jwks.json`,
        }
    })
    return cognitoList
}

export const compileCognitoKeys = async (cognitoList) => {
    const result = Object.keys(cognitoList).map(async (id) => {
        let item = cognitoList[id]
        const jwks = (await axios.get(item.jwks)).data
        item.pems = jwks.keys.reduce((acc, jwk) => {
            let key_id = jwk.kid
            let pem = jwkToPem(jwk)
            return { ...acc, [key_id]: pem }
        }, {})

        cognitoList[id] = item
        return Promise.resolve()
    })
    await Promise.all(result)

    return cognitoList
}

export const compileApplications = (raw, cognitoList) => {
    let id = 0
    let domainMap = {}
    let result = {}
    raw.applications.map((app) => {
        id++
        app.domains.map((domain) => {
            domainMap[domain] = id
        })
        let config = objectAssignDeep({}, raw.default, app)
        const cognito = Object.values(cognitoList).reduce((pick, item) => {
            if (
                item.name == config.cognito.name ||
                item.id == config.cognito.id
            ) {
                return item
            }
            return pick
        }, undefined)
        delete config.domains
        delete config.cognito
        config = objectAssignDeep({}, config, { cognito: { id: cognito.id } })
        result[id] = config
    })

    return {
        domains: domainMap,
        cognito: cognitoList,
        configs: result,
    }
}

export const select = (domain, fullConfig) => {
    const id = fullConfig.domains[domain]
    const config = fullConfig.configs[id]
    config.cognito = fullConfig.cognito[config.cognito.id]

    return config
}

export const requestS3 = async () => {
    const s3 = new AWS.S3()
    const response = await s3
        .getObject({
            Bucket: 'igshared-resources',
            Key: 'Lambda/config/serverlessauth.json',
        })
        .promise()
    return response.Body.toString('utf-8')
}

export default async (domain) => {
    const now = new Date()
    const compare = new Date(now.getTime())
    compare.setMinutes(compare.getMinutes() - 15)

    let config = global._edgeauth_config.fullConfig
    config = config == undefined ? {} : config // initialise

    if (!config.createdAt || config.createdAt <= compare) {
        log('rebuilding config')
        // This expects a JSON file thats fully computed for all domains
        const fullConfig = JSON.parse(requestS3())
        fullConfig.createdAt = now
        global._edgeauth_config.fullConfig = fullConfig
        config = fullConfig
    }

    return select(domain, config)
}
