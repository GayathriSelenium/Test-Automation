import fs from 'fs'
import { promisify } from 'util'

import * as lib from './lib'

(async () => {
    const file = await lib.requestLocal()
    const data = lib.parse(file)
    const cognitoList = await lib.compileCognitoKeys(lib.compileCognito(data))
    const config = lib.compileApplications(data, cognitoList)

    fs.writeFileSync('dist/serverlessauth.json', JSON.stringify(config))
})()
