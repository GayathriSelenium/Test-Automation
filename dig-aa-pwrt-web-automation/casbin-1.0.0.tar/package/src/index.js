import { newEnforcer, newModel } from 'casbin'
import bootstrap from '@origin/edgeauth-config'
import DynamoAdapter from 'casbin-dynamodb-adapter'

import npmdebug from 'debug'

const log = npmdebug('@origin/casbin')

export default async (domain) => {
    log('loading config')
    const config = await bootstrap(domain)
    log('constructing adapter')
    const adapter = new DynamoAdapter()
    log('constructing model')
    const model = newModel(config.casbin.model)

    log('casbin: enforcer')
    // no need to await here as its expected usage on the caller
    return newEnforcer(model, adapter)
}
